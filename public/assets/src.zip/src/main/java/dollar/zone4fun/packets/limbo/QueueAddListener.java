package dollar.zone4fun.packets.limbo;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.objects.ProxyUser;
import eu.dkcode.nats.packet.NatsListener;
import eu.dkcode.nats.packet.NatsPublish;

public class QueueAddListener extends NatsListener<QueueRequestPacket> {
    private ProxyCorePlugin instance;

    public QueueAddListener(ProxyCorePlugin instance) {
        super(new String[]{"queue-request-add"}, QueueRequestPacket.class);
        this.instance = instance;
    }

    @Override
    public void onPacket(QueueRequestPacket packet, String s) {
        ProxyUser user = this.instance.getProxyUsersManager().get(packet.getPlayerUUID());
        if (user == null || !user.isLogged()) return;

        NatsPublish publish = new NatsPublish.Builder()
                .channels(s)
                .object(packet)
                .build();

        this.instance.getNats().publish(publish);

    }
}

