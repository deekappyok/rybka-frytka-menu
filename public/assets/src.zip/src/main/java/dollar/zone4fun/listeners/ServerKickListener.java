package dollar.zone4fun.listeners;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.event.ServerKickEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

public class ServerKickListener implements Listener {
    private ProxyCorePlugin instance;
    private ServerInfo fallback;

    public ServerKickListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
        this.fallback = this.instance.getProxy().getServerInfo("limbo_1");
    }



    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerKickEvent(ServerKickEvent e) {
        if (fallback == null) {
            this.instance.getLogger().severe("Unable to find the specified fallback server!!");
        } else {
            String reason = BaseComponent.toLegacyText(e.getKickReasonComponent());
            String from = e.getKickedFrom().getName();
            e.setCancelServer(fallback);
            e.setCancelled(true);

            if (reason.contains("banned")) {
                e.getPlayer().disconnect(e.getKickReasonComponent());
                return;
            }

            System.out.println(reason);
            if (!from.equals(fallback.getName())) {
                e.getPlayer().sendMessage(new TextComponent(MessageHelper.colored("&4Utracono polaczenie z aktualnym serwerem.")));
                return;
            }
        }
    }
}
