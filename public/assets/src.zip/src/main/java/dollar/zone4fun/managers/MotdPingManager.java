package dollar.zone4fun.managers;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.config.ProxyServerConfig;
import dollar.zone4fun.helpers.MessageHelper;
import lombok.Getter;
import net.md_5.bungee.api.ServerPing;
import net.md_5.bungee.api.chat.TextComponent;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

@Getter
public class MotdPingManager {

    private final ProxyCorePlugin instance;
    private final String serverId;

    private ServerPing.PlayerInfo[] playerInfo;
    private int onlinePlayers;
    private ServerPing.Protocol version;
    private TextComponent description;

    public MotdPingManager(ProxyCorePlugin instance, String serverId) {
        this.instance = instance;
        this.serverId = serverId;
        updateServerPing();
        this.instance.getProxy().getScheduler().schedule(this.instance, this::updateServerPing, 5L, 5L, TimeUnit.SECONDS);
    }

    public void updateServerPing() {
        final ProxyServerConfig config = this.instance.getConfigManager().getProxyServerConfig();
        if (config == null) {
            this.onlinePlayers = this.instance.getChannelManager().getOnlineCount();
            this.version = new ServerPing.Protocol(MessageHelper.colored("&7Loading..."), 9);

            ServerPing.PlayerInfo[] playerInfo = new ServerPing.PlayerInfo[Arrays.asList(" ", "{PROXY}", " ").size()];
            for(int i = 0; i < Arrays.asList(" ", "{PROXY}", " ").size(); i++){
                playerInfo[i] = new ServerPing.PlayerInfo(
                        MessageHelper.colored(Arrays.asList(" ", "{PROXY}", " ").get(i)).replace("{PROXY}", this.serverId),
                        String.valueOf(i)
                );
            }
            this.playerInfo = playerInfo;

            this.description = new TextComponent(MessageHelper.colored("&7Loading...\n&7Loading..."));
            return;
        }

        /*if( Objects.isNull(motdConfig) || !uptimeControllerService.isControllerActive()){
            this.description = new TextComponent(ColorHelper.colorize("&c&lSerwer oczekuje na odpowiedź od kontrolera!\n&7Jeśli to trwa zbyt długo, skontaktuj się z administracją!"));
            return;
        }*/

        this.onlinePlayers = this.instance.getChannelManager().getOnlineCount();
        this.version = new ServerPing.Protocol(MessageHelper.colored("&7" + this.onlinePlayers), 9);

        ServerPing.PlayerInfo[] playerInfo = new ServerPing.PlayerInfo[config.getPlayerList().size()];
        for(int i = 0; i < config.getPlayerList().size(); i++){
            playerInfo[i] = new ServerPing.PlayerInfo(
                    MessageHelper.colored(config.getPlayerList().get(i)).replace("{PROXY}", this.serverId),
                    String.valueOf(i)
            );
        }
        this.playerInfo = playerInfo;

        this.description = new TextComponent(MessageHelper.colored(config.getFirstLine() + "\n"+ config.getSecondLine()));
    }
}
