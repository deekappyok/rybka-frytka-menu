package dollar.zone4fun.managers;

import com.google.common.collect.ImmutableSet;
import com.mongodb.async.SingleResultCallback;
import com.mongodb.client.model.Filters;
import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.objects.ProxyUser;
import dollar.zone4fun.packets.limbo.QueueRequestPacket;
import eu.dkcode.nats.packet.NatsPublish;
import org.bson.Document;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class ProxyUsersManager {
    private ProxyCorePlugin instance;
    private final Map<UUID, ProxyUser> proxyUsers = new HashMap<>();

    public ProxyUsersManager(ProxyCorePlugin instance) {
        this.instance = instance;
        load();
    }

    public void load(ProxyUser proxyUser) {
        this.proxyUsers.put(proxyUser.getUuid(), proxyUser);
    }

    public ProxyUser create(ProxyUser proxyUser) {
        this.proxyUsers.put(proxyUser.getUuid(), proxyUser);
        this.insert(proxyUser);
        return proxyUser;
    }

    public ProxyUser get(UUID uuid) {
        return this.proxyUsers.get(uuid);
    }

    public ProxyUser getByName(String name) {
        for (ProxyUser users : this.proxyUsers.values()) {
            if (users.getNickName().equals(name)) {
                return users;
            }
        }
        return null;
    }

    public CompletableFuture<ProxyUser> get(String name) {
        return CompletableFuture.supplyAsync(() -> proxyUsers.values().stream().filter(user -> user.getNickName().equals(name)).findFirst().orElse(null));
    }

    public ImmutableSet<ProxyUser> get() {
        return ImmutableSet.copyOf(this.proxyUsers.values());
    }

    public void clear(String name) {
        this.proxyUsers.remove(name);
    }

    public void addQueue(UUID uuid) {

        QueueRequestPacket packet = new QueueRequestPacket(uuid);

        NatsPublish publish = new NatsPublish.Builder()
                .channels("limbo-queue-add")
                .object(packet)
                .build();

        this.instance.getNats().publish(publish);
    }

    public void load() {

        this.instance.getDatabase().loadAll("network-proxy-users", ProxyUser.class, new SingleResultCallback<Collection<ProxyUser>>() {
            @Override
            public void onResult(Collection<ProxyUser> proxyUsers, Throwable throwable) {
                if (throwable != null) {
                    System.out.println("Wyjebalo sie: " + throwable);
                    return;
                }
                proxyUsers.forEach(proxyUser -> load(proxyUser));
                System.out.println("Loaded " + proxyUsers.size() + " proxyUsers");
            }
        });

    }

    public void insert(ProxyUser proxyUser) {
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-users").insertOne(Document.parse(this.instance.getDatabase().getGson().toJson(proxyUser)), (aVoid, throwable) -> {
        });
    }

    public void synchronize(ProxyUser proxyUser) {
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-users").findOneAndReplace(new Document("nickName", proxyUser.getNickName()), Document.parse(this.instance.getDatabase().getGson().toJson(proxyUser)), (aVoid, throwable) -> {
        });
    }

    public void removeProxyUser(ProxyUser proxyUser) {
        this.proxyUsers.remove(proxyUser.getUuid());
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-users")
                .deleteOne(Filters.eq("nickName", proxyUser.getNickName()), (result, throwable) -> {
                    if (throwable != null) {
                        System.out.println("Error while removing ProxyUser: " + throwable.getMessage());
                    } else {
                        long deletedCount = result.getDeletedCount();
                        if (deletedCount > 0) {
                            System.out.println("ProxyUser removed successfully.");
                        } else {
                            System.out.println("ProxyUser not found or already removed.");
                        }
                    }
                });
    }

}
