package dollar.zone4fun.listeners;

import com.google.common.collect.Maps;
import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.config.SettingsServerConfig;
import dollar.zone4fun.configuration.channel.ProxyMessages;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.DateHelper;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.managers.ConfigManager;
import dollar.zone4fun.objects.Bans;
import dollar.zone4fun.objects.Channel;
import dollar.zone4fun.objects.ProxyUser;
import dollar.zone4fun.tasks.UserTimeoutTask;
import io.nats.client.Message;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.PendingConnection;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.PreLoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PreLoginListener implements Listener {

    private ProxyCorePlugin instance;
    private Map<String, Long> CONNECTIONS_LIMITS = Maps.newConcurrentMap();
    private ConfigManager configManager;

    public PreLoginListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
        this.configManager = this.instance.getConfigManager();
    }

    @EventHandler(priority = 64)
    public void onPreLogin(PreLoginEvent event) {

        if (event.getConnection().getVersion() != 47) {
            event.setCancelled(true);
            event.setCancelReason(new TextComponent(MessageHelper.colored("&cDopuszczalna Wersja 1.8.8")));
            return;
        }

        if (this.instance.getPremiumManager().getCurrentAccounts() >= this.instance.getPremiumManager().getMaxNewAccounts()) {
            event.setCancelled(true);
            event.setCancelReason(new TextComponent(MessageHelper.colored("&4Zbyt duzo osob probuje polaczyc sie z serwerem\n&4Sprobuj ponownie za chwile.")));
            return;
        }

        Pattern p = Pattern.compile("[^a-zA-Z0-9_]");
        Matcher m = p.matcher(event.getConnection().getName());

        if (m.find()) {
            event.setCancelled(true);
            event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.error.nickname.letters")));
            event.completeIntent(this.instance);
            return;
        }

        Bans bans;
        if ((bans = this.instance.getBansManager().get(event.getConnection().getName())) != null) {
            event.setCancelled(true);
            event.setCancelReason(new TextComponent(MessageHelper.colored(this.instance.getBansManager().getReason(bans))));
            return;
        }

        Channel channel = this.instance.getChannelManager().get("limbo_1");
        if (channel == null || !channel.isOnline()) {
            event.setCancelled(true);
            event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.server.connect.error")));
            return;
        }

        // dorobic blokade przy wejsciu jeszcze jednej osoby na ten sam niczek

        event.registerIntent(this.instance);
        this.instance.getProxy().getScheduler().runAsync(this.instance, () -> {

            SettingsServerConfig serverConfig = this.instance.getConfigManager().getServerConfig();
            if (serverConfig == null) {
                event.setCancelled(true);
                event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.server.connect.error"))); // blad
                event.completeIntent(this.instance);
                return;
            }

            if (this.instance.getProxy().getOnlineCount() >= serverConfig.getSlots() && !serverConfig.getBypassPlayers().contains(event.getConnection().getName())) {
                event.setCancelled(true);
                event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.server.full")));
                event.completeIntent(this.instance);
                return;
            }

            if (serverConfig.isWhitelist() && !serverConfig.getWlPlayers().contains(event.getConnection().getName())) {
                event.setCancelled(true);
                event.setCancelReason(new TextComponent(MessageHelper.colored(
                        "  &6&lWhitelist &f&lON\n" +
                        "\n" +
                        "  &6Strona: &7Zone4Fun.pl\n" +
                        "  &6Facebook: &7fb.Zone4Fun.pl\n" +
                        "  &6Discord: &7dc.Zone4Fun.pl\n" +
                        "\n" +
                        "  &7&oSerwer aktualnie nie jest dostepny dla graczy...\n")));
                event.completeIntent(this.instance);
                return;
            }

            String address = event.getConnection().getAddress().getAddress().getHostAddress();
            Long connectionTime = this.getConnectionsLimits().get(address);
            if (connectionTime != null && connectionTime >= System.currentTimeMillis()) {
                event.setCancelled(true);
                event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.fast.connect.server")));
                event.completeIntent(this.instance);
                return;
            }

            ProxyUser proxyUser = this.instance.getProxyUsersManager().getByName(event.getConnection().getName());
            boolean isPremium;
            if (proxyUser == null) {

                int premiumId = this.instance.getPremiumManager().isPremium(event.getConnection().getName()).join();

                if (premiumId == -1) {
                    this.getConnectionsLimits().put(address, System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(10L));
                    this.instance.getPremiumManager().getCacheLogin().remove(event.getConnection().getName());

                    event.setCancelled(true);
                    event.setCancelReason(new TextComponent(this.configManager.getProxyMessages().getMessage("proxy.mojang.api.is.down")));
                    event.completeIntent(this.instance);
                    return;
                }

                isPremium = this.instance.getPremiumManager().replace(premiumId);

            } else {
                isPremium = proxyUser.isPremium();
            }

            event.getConnection().setOnlineMode(isPremium);
            this.getConnectionsLimits().put(address, System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(5L));
            event.completeIntent(this.instance);

        });
    }

    public Map<String, Long> getConnectionsLimits() {
        return this.CONNECTIONS_LIMITS;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onLoginFirst(final PlayerDisconnectEvent event) {
        this.CONNECTIONS_LIMITS.put(event.getPlayer().getAddress().getAddress().getHostAddress(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3L));
    }
}
