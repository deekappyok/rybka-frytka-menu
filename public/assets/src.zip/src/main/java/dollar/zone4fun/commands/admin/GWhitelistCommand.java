package dollar.zone4fun.commands.admin;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.config.SettingsServerConfig;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class GWhitelistCommand extends AbstractCommand {
    private ProxyCorePlugin instance;

    public GWhitelistCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
        this.instance = instance;
    }

    public void execute(CommandSender sender, String[] args) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = ProxyServer.getInstance().getPlayer(sender.getName());
            ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
            if (user == null) {
                sender.sendMessage(new TextComponent(this.getInstance().getConfigManager().getProxyMessages().getMessage("proxy.command.null")));
                return;
            }
            if (!user.getRankType().can(RankTypeEnum.ADMIN)) {
                sender.sendMessage(new TextComponent(this.getInstance().getConfigManager().getProxyMessages().getMessage("proxy.command.null")));
                return;
            }
        }
        if (args.length < 1) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /whitelist <list/on/off/add/remove> <nick>")));
            return;
        }
        if (args[0].equals("list")) {
            sender.sendMessage(new TextComponent(MessageHelper.colored(
                    "&7Status whitelist: " + "\n" +
                            "&7Osoby na whitelist: \n&7- &a" + this.instance.getConfigManager().getServerConfig().getWlPlayers().toString().replace(",", "\n&7-&a").replace("[", "").replace("]", "")
            )));
            return;
        }
        if ((args[0].equals("on") || args[0].equals("off"))) {
            SettingsServerConfig serverConfig = this.instance.getConfigManager().getServerConfig();
            serverConfig.setWhitelist(args[0].equals("on"));
            this.instance.getConfigManager().reloadServerConfig(serverConfig);
            sender.sendMessage(new TextComponent(MessageHelper.colored((args[0].equals("on") ? "&aWlaczyles" : "&cWylaczyles") + " &7whiteliste na proxy!")));
            return;
        }
        if (args[0].equals("add") && args[1] != null) {
            SettingsServerConfig serverConfig = this.instance.getConfigManager().getServerConfig();
            String name = args[1];
            if (serverConfig.getWlPlayers().contains(name)) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Podany gracz znajduje sie juz na whitelist!")));
                return;
            }
            serverConfig.getWlPlayers().add(name);
            this.instance.getConfigManager().reloadServerConfig(serverConfig);
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Dodales gracza &f" + name + " &7do whitelisty na proxy!")));
            return;
        }
        if (args[0].equals("remove") && args[1] != null) {
            SettingsServerConfig serverConfig = this.instance.getConfigManager().getServerConfig();
            String name = args[1];
            if (!serverConfig.getWlPlayers().contains(name)) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Nie znaleziono podanego gracza na whitelist.")));
                return;
            }
            serverConfig.getWlPlayers().remove(name);
            this.instance.getConfigManager().reloadServerConfig(serverConfig);
            sender.sendMessage(MessageHelper.colored("&7Usuneles gracza &f" + name + " &7z whitelisty na proxy!"));
            return;
        }
        sender.sendMessage(MessageHelper.colored("&cPoprawne użycie: /whitelist <list/on/off/add/remove> <nick>"));
        return;
    }
}
