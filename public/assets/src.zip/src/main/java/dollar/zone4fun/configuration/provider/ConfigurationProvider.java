package dollar.zone4fun.configuration.provider;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.configuration.Configuration;

import java.io.File;

public class ConfigurationProvider {
    private final ProxyCorePlugin instance;
    private final ObjectMapper objectMapper;
    private Configuration configuration;

    public ConfigurationProvider(ProxyCorePlugin instance) {
        this.instance = instance;
        (this.objectMapper = new ObjectMapper()).configure(SerializationFeature.INDENT_OUTPUT, true);
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.load(this.instance);
    }

    private void load(ProxyCorePlugin instance) {
        try {
            if (!instance.getDataFolder().exists()) {
                instance.getDataFolder().mkdir();
            }

            File file = new File(instance.getDataFolder(), "config.json");
            if (!file.exists()) {
                this.configuration = new Configuration("nats://localhost:4222", "proxy_1", "PROXY");
                this.objectMapper.writeValue(file, this.configuration);
                return;
            }

            this.configuration = this.objectMapper.readValue(file, Configuration.class);
        } catch (Exception exc) {
            exc.printStackTrace();
        }

    }

    public Configuration provide() {
        return this.configuration;
    }
}
