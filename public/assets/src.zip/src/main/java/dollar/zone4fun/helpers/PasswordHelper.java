package dollar.zone4fun.helpers;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordHelper {
    private static final String key = "aUsohlfSPF7tgLB96X7JenJm1CBPtcRR3AaGGoOEGrMIKZyZWcYwcG7iSUpF";

    public static String encrypt(String input) {
        try {
            String modifiedInput = key.substring(0, 7) + input.charAt(0) + key.substring(7, 16) + input.substring(1) + key.substring(16);
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] messageDigest = md.digest(modifiedInput.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);

            return String.format("%032x", no);
        } catch (NoSuchAlgorithmException var6) {
            throw new RuntimeException(var6);
        }
    }
}
