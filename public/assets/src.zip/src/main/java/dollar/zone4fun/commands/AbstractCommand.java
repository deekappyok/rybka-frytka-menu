package dollar.zone4fun.commands;

import dollar.zone4fun.ProxyCorePlugin;
import lombok.Getter;
import net.md_5.bungee.api.plugin.Command;

@Getter
public abstract class AbstractCommand extends Command {
    private final ProxyCorePlugin instance;

    public AbstractCommand(ProxyCorePlugin instance, String name) {
        super(name);
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerCommand(this.instance, this);
    }

    public String getMessage(String id) {
        return this.instance.getConfigManager().getProxyMessages().getMessage(id);
    }
}
