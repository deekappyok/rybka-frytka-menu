package dollar.zone4fun.commands.admin;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.config.ProxyServerConfig;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Arrays;

public class MotdCommand extends AbstractCommand {
    private ProxyCorePlugin instance;

    public MotdCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
        this.instance = instance;
    }

    public void execute(CommandSender sender, String[] args) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = ProxyServer.getInstance().getPlayer(sender.getName());
            ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
            if (user == null) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
            if (!user.getRankType().can(RankTypeEnum.ADMIN)) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
        }
        if (args.length < 1) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /motd <1/2> <motd>")));
            return;
        }
        if (args[0].equals("1") || args[0].equals("2") && args[2] != null) {
            ProxyServerConfig serverConfig = this.instance.getConfigManager().getProxyServerConfig();
            String motd = MessageHelper.colored(String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
            if (args[0].equals("1")) serverConfig.setFirstLine(motd);
            if (args[0].equals("2")) serverConfig.setSecondLine(motd);
            this.instance.getConfigManager().reloadProxyServerConfig(serverConfig);
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Zmieniles &a" + args[0] + " &7linijke motd na:\n" + motd)));
            return;
        }
        sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /motd <1/2> <motd>")));
    }
}

