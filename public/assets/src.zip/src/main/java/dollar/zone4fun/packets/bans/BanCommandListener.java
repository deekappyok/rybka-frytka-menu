package dollar.zone4fun.packets.bans;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.Bans;
import dollar.zone4fun.objects.BansRequest;
import dollar.zone4fun.objects.ProxyUser;
import eu.dkcode.nats.packet.NatsListener;
import eu.dkcode.nats.packet.NatsPublish;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class BanCommandListener extends NatsListener<BansRequest> {
    private ProxyCorePlugin instance;

    public BanCommandListener(ProxyCorePlugin instance) {
        super(new String[]{"ban-command-channel"}, BansRequest.class);
        this.instance = instance;
    }

    @Override
    public void onPacket(BansRequest packet, String s) {

        if (packet.getCallBack().equals("KICK_COMMAND")) {
            ProxiedPlayer player = ProxyCorePlugin.getInstance().getProxy().getPlayer(packet.getBans().getTargetUuid());
            if (player == null) {
                packet.setCallBack("PLAYER_NOT_FOUND");
                sendCallBack(packet, s);
                return;
            }
            player.disconnect(new TextComponent(MessageHelper.colored(this.instance.getBansManager().getKickReason(packet.getBans()))));
            packet.setCallBack("KICKED");
            sendCallBack(packet, s);
            return;
        }

        if (packet.getCallBack().equals("UNBAN_COMMAND")) {

            if (this.instance.getBansManager().get(packet.getBans().getTargetUuid()) == null) {
                packet.setCallBack("EMPTY_BAN");
                sendCallBack(packet, s);
                return;
            }

            this.instance.getBansManager().removeProxyUser(packet.getBans());
            packet.setCallBack("UNBANNED");
            sendCallBack(packet, s);
            return;
        }

        if (this.instance.getBansManager().get(packet.getBans().getTargetUuid()) != null) {
            Long time = this.instance.getBansManager().get(packet.getBans().getTargetUuid()).getTime();
            if (time != -1L && time <= System.currentTimeMillis()) {
                this.instance.getBansManager().removeProxyUser(packet.getBans());
                packet.setCallBack("UNBANNED");
                sendCallBack(packet, s);
                return;
            }
            packet.setCallBack("IS_BANNED");
            sendCallBack(packet, s);
            return;
        }

        this.instance.getBansManager().create(packet.getBans());

        ProxiedPlayer player = ProxyCorePlugin.getInstance().getProxy().getPlayer(packet.getBans().getTargetUuid());
        if (player != null) {
            player.disconnect(new TextComponent(MessageHelper.colored(this.instance.getBansManager().getReason(packet.getBans()))));
        }

        packet.setCallBack("CAN_BAN");
        sendCallBack(packet, s);
    }

    public void sendCallBack(BansRequest packet, String s) {
        NatsPublish publish = new NatsPublish.Builder()
                .channels(s)
                .object(packet)
                .build();

        this.instance.getNats().publish(publish);
    }
}
