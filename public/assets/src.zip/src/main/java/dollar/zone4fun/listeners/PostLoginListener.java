package dollar.zone4fun.listeners;

import com.google.common.collect.Maps;
import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.DateHelper;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import dollar.zone4fun.tasks.UserTimeoutTask;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.PreLoginEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class PostLoginListener implements Listener {

    private ProxyCorePlugin instance;

    public PostLoginListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onLoginFirst(PostLoginEvent event) {
        final ProxiedPlayer player = event.getPlayer();

        ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());

        if (user == null) {

            int premiumId = this.instance.getPremiumManager().isPremium(player.getName()).join();

            user = new ProxyUser(
                    player.getUniqueId(),
                    player.getName(),
                    RankTypeEnum.PLAYER,
                    this.instance.getPremiumManager().replace(premiumId),
                    premiumId == 1,
                    "",
                    DateHelper.getDate(System.currentTimeMillis()),
                    false
            );

            if (!user.isPremium()) this.instance.getProxy().getScheduler().schedule(this.instance, new UserTimeoutTask(player), 30L, TimeUnit.SECONDS);
            if (user.isPremium()) {
                user.setLogged(true);
                player.sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.instance.getConfigManager().getProxyMessages().getMessage("proxy.correct.login.premium.account")));
            }
            this.instance.getProxyUsersManager().create(user);
            return;
        }
        if (!user.isPremium()) this.instance.getProxy().getScheduler().schedule(this.instance, new UserTimeoutTask(player), 30L, TimeUnit.SECONDS);
        if (user.isPremium()) {
            user.setLogged(true);
            player.sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(this.instance.getConfigManager().getProxyMessages().getMessage("proxy.correct.login.premium.account")));
        }
        this.instance.getProxyUsersManager().synchronize(user);
    }
}
