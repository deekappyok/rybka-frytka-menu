package dollar.zone4fun.objects;

import dollar.zone4fun.enums.rank.RankTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.UUID;

@Data
@AllArgsConstructor
public class ProxyUser {
    private UUID uuid;
    private String nickName;
    private RankTypeEnum rankType;
    private boolean premium;
    private boolean registered;
    private String password;
    private String registerTime;
    private boolean logged;
}
