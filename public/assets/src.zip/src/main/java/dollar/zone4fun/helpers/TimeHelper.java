package dollar.zone4fun.helpers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TimeHelper {

    public static String getDate(long data) {
        Date time = new Date(data);
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy ");
        return dateFormat.format(time);
    }

    public static String secondsToString(Long l) {
        String time = (int) (l - System.currentTimeMillis()) / 1000 + "s";
        return time;
    }

    public static long parseString(String string) {
        if (string.equalsIgnoreCase("0")) {
            return 0;
        }
        List<String> list = new ArrayList<>();
        String c;
        int goBack = 0;
        for (int i = 0; i < string.length(); i++) {
            c = String.valueOf(string.charAt(i));
            if (c.matches("[a-zA-Z]")) {
                list.add(string.substring(goBack, i + 1));
                goBack = i + 1;
            }
        }
        long amount;
        long total = 0;
        char ch;
        for (String st : list) {
            ch = st.charAt(st.length() - 1);
            if (st.length() != 1 && String.valueOf(ch).matches("[M,w,d,h,m,s]")) {
                amount = Math.abs(Integer.parseInt(st.substring(0, st.length() - 1)));
                switch (ch) {
                    case 's':
                        total += (amount * 1000);
                        break;
                    case 'm':
                        total += (amount * 1000 * 60);
                        break;
                    case 'h':
                        total += (amount * 1000 * 3600);
                        break;
                    case 'd':
                        total += (amount * 1000 * 3600 * 24);
                        break;
                    case 'w':
                        total += (amount * 1000 * 3600 * 24 * 7);
                        break;
                }
            }
        }
        if (total == 0) return -1;
        return total;
    }
}
