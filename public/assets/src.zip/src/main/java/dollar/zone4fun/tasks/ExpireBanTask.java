package dollar.zone4fun.tasks;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.enums.ChannelType;
import dollar.zone4fun.objects.Bans;
import dollar.zone4fun.objects.Channel;

import java.util.concurrent.TimeUnit;

public class ExpireBanTask implements Runnable {
    private final ProxyCorePlugin instance;

    public ExpireBanTask(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getScheduler().schedule(this.instance, this, 1L, 1L, TimeUnit.SECONDS);
    }

    public void run() {
        for (Bans bans : this.instance.getBansManager().get()) {
            Long time = this.instance.getBansManager().get(bans.getTargetUuid()).getTime();
            if (time != -1L && time <= System.currentTimeMillis()) {
                this.instance.getBansManager().removeProxyUser(bans);
            }
        }
    }
}
