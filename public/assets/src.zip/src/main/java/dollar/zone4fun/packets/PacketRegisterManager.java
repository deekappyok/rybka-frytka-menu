package dollar.zone4fun.packets;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.packets.bans.BanCommandListener;
import dollar.zone4fun.packets.limbo.QueueAddListener;
import dollar.zone4fun.packets.server.ServerDisabledListener;
import dollar.zone4fun.packets.server.ServerEnabledListener;
import eu.dkcode.nats.NatsWrapper;

public class PacketRegisterManager {
    private final ProxyCorePlugin instance;
    private final NatsWrapper nats;

    public PacketRegisterManager(ProxyCorePlugin instance, NatsWrapper nats) {
        this.instance = instance;
        this.nats = nats;
        this.register();
    }

    public void register() {
        this.nats.subscribe(new ServerEnabledListener());
        this.nats.subscribe(new ServerDisabledListener());
        this.nats.subscribe(new QueueAddListener(this.instance));
        this.nats.subscribe(new BanCommandListener(this.instance));
    }
}
