package dollar.zone4fun.listeners;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.managers.MotdPingManager;
import net.md_5.bungee.api.ServerPing;
import net.md_5.bungee.api.event.ProxyPingEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

public class PingServerListener implements Listener {
    private ProxyCorePlugin instance;

    public PingServerListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPing(ProxyPingEvent event) {
        ServerPing ping = event.getResponse();
        MotdPingManager serverPingManager = this.instance.getMotdPingManager();
        ping.getPlayers().setSample(serverPingManager.getPlayerInfo());
        ping.getPlayers().setOnline(serverPingManager.getOnlinePlayers());
        ping.setVersion(serverPingManager.getVersion());
        ping.setDescriptionComponent(serverPingManager.getDescription());
        event.setResponse(ping);
    }
}
