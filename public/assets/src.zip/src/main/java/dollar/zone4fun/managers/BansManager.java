package dollar.zone4fun.managers;

import com.google.common.collect.ImmutableSet;
import com.mongodb.async.SingleResultCallback;
import com.mongodb.client.model.Filters;
import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.DateHelper;
import dollar.zone4fun.objects.Bans;
import dollar.zone4fun.objects.ProxyUser;
import dollar.zone4fun.packets.limbo.QueueRequestPacket;
import eu.dkcode.nats.packet.NatsPublish;
import org.bson.Document;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class BansManager {
    private ProxyCorePlugin instance;
    private final Map<UUID, Bans> bansMap = new HashMap<>();

    public BansManager(ProxyCorePlugin instance) {
        this.instance = instance;
        load();
    }

    public void load(Bans bans) {
        this.bansMap.put(bans.getTargetUuid(), bans);
    }

    public Bans create(Bans bans) {
        this.bansMap.put(bans.getTargetUuid(), bans);
        this.insert(bans);
        return bans;
    }

    public Bans get(UUID targetUuid) {
        return this.bansMap.get(targetUuid);
    }

    public String getReason(Bans bans) {
        return "&8&m          &8( &4Blokada Konta &8)&m          \n\n" +
                "&4&l● &cPrzez: &f" + bans.getBanner() + "\n" +
                "&4&l● &cPowód: &f" + bans.getReason() + "\n" +
                "&4&l● &cWygasa: &f" + (bans.getTime() == -1L ? "NIGDY" :  DateHelper.getDate(bans.getTime(), false)) + "\n\n" +
                "&8&m          &8( &4Blokada Konta &8)&m          ";
    }

    public String getKickReason(Bans bans) {
        return "&8&m          &8( &4Kick z Serwera &8)&m          \n\n" +
                "&4&l● &cPrzez: &f" + bans.getBanner() + "\n" +
                "&4&l● &cPowód: &f" + bans.getReason() + "\n\n" +
                "&8&m          &8( &4Kick z Serwera &8)&m          ";
    }

    public Bans get(String targetName) {
        return this.bansMap.values()
                .stream()
                .filter(bans -> bans.getTargetName().equals(targetName))
                .findFirst()
                .orElse(null);
    }

    public ImmutableSet<Bans> get() {
        return ImmutableSet.copyOf(this.bansMap.values());
    }

    public void clear(UUID targetUuid) {
        this.bansMap.remove(targetUuid);
    }

    public void load() {

        this.instance.getDatabase().loadAll("network-proxy-bans", Bans.class, new SingleResultCallback<Collection<Bans>>() {
            @Override
            public void onResult(Collection<Bans> bans, Throwable throwable) {
                if (throwable != null) {
                    System.out.println("Wyjebalo sie: " + throwable);
                    return;
                }
                bans.forEach(bans1 -> load(bans1));
                System.out.println("Loaded " + bans.size() + " bans");
            }
        });

    }

    public void insert(Bans bans) {
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-bans").insertOne(Document.parse(this.instance.getDatabase().getGson().toJson(bans)), (aVoid, throwable) -> {
        });
    }

    public void synchronize(Bans bans) {
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-bans").findOneAndReplace(new Document("targetName", bans.getTargetName()), Document.parse(this.instance.getDatabase().getGson().toJson(bans)), (aVoid, throwable) -> {
        });
    }

    public void removeProxyUser(Bans bans) {
        this.bansMap.remove(bans.getTargetUuid());
        this.instance.getDatabase().getMongoDatabase().getCollection("network-proxy-bans")
                .deleteOne(Filters.eq("targetName", bans.getTargetName()), (result, throwable) -> {
                    if (throwable != null) {
                        System.out.println("Error while removing ProxyUser: " + throwable.getMessage());
                    } else {
                        long deletedCount = result.getDeletedCount();
                        if (deletedCount > 0) {
                            System.out.println("Bans removed successfully.");
                        } else {
                            System.out.println("Bans not found or already removed.");
                        }
                    }
                });
    }

}

