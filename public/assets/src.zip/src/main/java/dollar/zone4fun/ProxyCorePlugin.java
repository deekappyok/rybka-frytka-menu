package dollar.zone4fun;

import dollar.zone4fun.commands.admin.*;
import dollar.zone4fun.commands.user.ChangePasswordCommand;
import dollar.zone4fun.commands.user.LoginCommand;
import dollar.zone4fun.commands.user.PingCommand;
import dollar.zone4fun.commands.user.RegisterCommand;
import dollar.zone4fun.configuration.provider.ConfigurationProvider;
import dollar.zone4fun.databases.Database;
import dollar.zone4fun.listeners.*;
import dollar.zone4fun.managers.*;
import dollar.zone4fun.packets.PacketRegisterManager;
import dollar.zone4fun.packets.server.ServerPacket;
import dollar.zone4fun.packets.server.ServersRequestPacket;
import dollar.zone4fun.tasks.ExpireBanTask;
import dollar.zone4fun.tasks.ProxyUpdateTask;
import dollar.zone4fun.tasks.UserMessageTask;
import eu.dkcode.configuration.ConfigLoader;
import eu.dkcode.nats.NatsWrapper;
import eu.dkcode.nats.NatsWrapperImpl;
import eu.dkcode.nats.serializer.DefaultSerializerImpl;
import lombok.Getter;
import lombok.SneakyThrows;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.plugin.Plugin;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

@Getter
public class ProxyCorePlugin extends Plugin {
    @Getter
    public static ProxyCorePlugin instance;
    private ConfigurationProvider provider;
    private ConfigLoader configLoader;
    private Database database;
    private NatsWrapper nats;

    private ChannelManager channelManager;
    private ProxyUsersManager proxyUsersManager;
    private PremiumManager premiumManager;
    private MotdPingManager motdPingManager;
    private BansManager bansManager;

    @SneakyThrows
    @Override
    public void onEnable() {
        instance = this;

        this.provider = new ConfigurationProvider(this);
        this.configLoader = new ConfigLoader();
        this.database = new Database();
        this.nats = new NatsWrapperImpl.Builder()
                .uri("nats://95.214.53.231:4222")
                .id(this.provider.provide().getServerName())
                .serializer(new DefaultSerializerImpl())
                .threadPoolSize(2)
                .build();
        new PacketRegisterManager(this, this.nats);


        //Managers
        this.channelManager = new ChannelManager(this.nats);
        this.proxyUsersManager = new ProxyUsersManager(this);
        this.premiumManager = new PremiumManager();
        this.motdPingManager = new MotdPingManager(this, this.provider.provide().getServerName());
        this.bansManager = new BansManager(this);


        // Listeners
        new ChatListener(this);
        new PingServerListener(this);
        new PlayerDisconnectListener(this);
        new PostLoginListener(this);
        new PreLoginListener(this);
        new ServerConnectListener(this);


        // Commands
        new RegisterCommand(this, "register");
        new LoginCommand(this, "login");
        new ChangePasswordCommand(this, "changepassword");
        new PingCommand(this, "ping");
        new GWhitelistCommand(this, "gwhitelist");
        new GSlotsCommand(this, "gslots");
        new MotdCommand(this, "motd");
        new AuthCommand(this, "auth");
        new GPermissionsCommand(this, "gpex");

        // Tasks
        new UserMessageTask(this);
        new ProxyUpdateTask(this);
        new ExpireBanTask(this);

        // Other

        CompletableFuture<ServersRequestPacket> future = this.nats.request(
                "servers-request",
                new ServersRequestPacket(new ArrayList<>()),
                ServersRequestPacket.class
        );

        future.thenAccept(response -> {
            response.getServers().forEach(this::loadServer);
        }).exceptionally(throwable -> {
            System.out.println(throwable.getCause());
            return null;
        });

        System.out.println("[zone4fun-proxy-plugin] Loading complete!");
    }

    @Override
    public void onDisable() {

    }

    public void loadServer(ServerPacket serverPacket) {
        ProxyServer.getInstance().getServers().put(serverPacket.getServerName(),
                ProxyServer.getInstance().constructServerInfo(
                        serverPacket.getServerName(),
                        new InetSocketAddress(serverPacket.getServerAddress(), serverPacket.getPort()),
                        "null",
                        false
                ));
        this.getLogger().info("Pomyslnie zaladowano do configu serwer: " + serverPacket.getServerName());
    }
}