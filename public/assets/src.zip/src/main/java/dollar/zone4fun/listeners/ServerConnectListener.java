package dollar.zone4fun.listeners;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.Channel;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

public class ServerConnectListener implements Listener {
    private ProxyCorePlugin instance;

    public ServerConnectListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onServerConnect(ServerConnectEvent event) {
        if (event.getReason().equals(ServerConnectEvent.Reason.JOIN_PROXY)) {
            ProxiedPlayer player = event.getPlayer();
            Channel channel = this.instance.getChannelManager().get("limbo_1");
            if (channel == null || !channel.isOnline()) {
                player.disconnect(new TextComponent(MessageHelper.colored("&cBlad w polaczeniu do serwera!\n&cSprobuj ponownie za chwile...")));
                event.setCancelled(true);
                return;
            }
            event.setTarget(ProxyServer.getInstance().getServerInfo(channel.getChannelId()));
        }
    }
}
