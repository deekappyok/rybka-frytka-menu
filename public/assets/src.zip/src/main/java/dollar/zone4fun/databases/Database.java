package dollar.zone4fun.databases;

import com.google.gson.Gson;
import com.mongodb.async.SingleResultCallback;
import com.mongodb.async.client.MongoClient;
import com.mongodb.async.client.MongoClients;
import com.mongodb.async.client.MongoDatabase;
import lombok.Getter;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Collection;

public class Database {

    private final MongoClient client;
    private final MongoDatabase database;
    @Getter private final Gson gson = GsonFactory.getCompactGson();

    public Database() {
        client = MongoClients.create("mongodb://root:97aRiha8Z9ullSyYmXodzJqTGcO5oSDI@95.214.53.231:27018");
        database = client.getDatabase("zone4fun-proxy-database");
        System.out.println("Databases connected to: zone4fun-proxy-database");
    }

    public MongoDatabase getMongoDatabase() {
        return database;
    }

    public <T> void loadAll(String collection, Class<T> clazz, SingleResultCallback<Collection<T>> callback) {
        getMongoDatabase().getCollection(collection)
                .find()
                .map(Document::toJson)
                .map(s -> gson.fromJson(s,clazz))
                .into(new ArrayList<>(), callback);
    }

    public <T> void findOne(String collection, Class<T> clazz, String key, Object value, SingleResultCallback<Document> callback) {
        getMongoDatabase().getCollection(collection)
                .find(new Document(key, value.toString()))
                .first(callback);
    }

    public void disconnect() {
        this.client.close();
    }
}

