package dollar.zone4fun.configuration.channel;

import net.md_5.bungee.api.ChatColor;

import java.util.HashMap;

public class ProxyMessages {
    private final HashMap<String, String> messages;

    public ProxyMessages() {
        this.messages = new HashMap<>();
        this.messages.put("proxy.error.to.establish.account", "&cNie udalo się utworzyc twojego konta.");
        this.messages.put("proxy.error.command.for.premium", "&cTa komenda nie jest dostepna dla graczy z kontem premium");
        this.messages.put("proxy.error.register.account", "&cTwoje konto nie zostalo zarejestrowane.");
        this.messages.put("proxy.correct.coomand.changepassowrd", "&7Poprawne uzycie: &c/changepassword <stare_haslo> <nowe_haslo>");
        this.messages.put("proxy.error.password", "&cPodane haslo jest nieprawidlowe");
        this.messages.put("proxy.correct.password.change", "&cTwoje haslo zostalo &apomyslnie &czmienione!");
        this.messages.put("proxy.login.account", "&cJestes juz zalogowany!");
        this.messages.put("proxy.correct.command.login", "&7Poprawne uzycie: &c/login <haslo>");
        this.messages.put("proxy.correct.login.nonpremium", "&aPomyslnie zalogowano za pomoca konta No-Premium!");
        this.messages.put("proxy.user.not.login", "&cNie jestes zalogowany do swojego konta.");
        this.messages.put("proxy.user.ping", "&aTwoj aktualny ping wynosi &c{PING}&ams!");
        this.messages.put("proxy.account.now.register", "&cTwoje konto zostalo juz zarejestrowane!");
        this.messages.put("proxy.register.command", "&7Poprawne uzycie: &c/register <haslo> <haslo>");
        this.messages.put("proxy.correct.register.nonpremium.account", "&aPomyslnie zarejestrowano za pomoca konta No-Premium!");
        this.messages.put("proxy.correct.login.premium.account", "&aPomyslnie zalogowales sie za pomoca konta premium!");
        this.messages.put("proxy.mojang.api.is.down", "&cApi mojangu nie dziala. Sprobuj ponownie za chwile!");
        this.messages.put("proxy.error.nickname.letters", "&cTen nick zawiera niedozwolone znaki!");
        this.messages.put("proxy.server.connect.error", "&cBlad w polaczeniu do serwera!\n&cSprobuj ponownie za chwile\n&6Jesli problem utrzymuje sie dluzszy czas zglos go na naszym discordzie!");
        this.messages.put("proxy.fast.connect.server", "&4Zbyt szybko laczysz sie do serwera\n&4Sprobuj ponownie za chwile!");
        this.messages.put("proxy.connect.global.limit", "&4Zbyt duzo osob probuje polaczyc sie z serwerem\n&4Sprobuj ponownie za chwile.");
        this.messages.put("proxy.register.command.to.use", "&7Zarejestruj swoje konto uzywajac: &a/register <haslo> <powtorz_haslo>");
        this.messages.put("proxy.login.command.to.use", "&7Zaloguj sie do konta uzywając komendy: &a/login <haslo>");
        this.messages.put("proxy.server.offline", "&4Serwer docelowy jest &cOffline&4.");
        this.messages.put("proxy.server.full", "&4Serwer jest pelny!\n&4Sprobuj za chwile ponownie.");
        this.messages.put("proxy.server.working", "&4Na serwerze trwaja prace techniczne!");
        this.messages.put("proxy.command.null", "&cPodana komenda nie istnieje lub nie masz do niej uprawnien!");
    }

    public String getMessage(String id) {
        if (!this.messages.containsKey(id)) return "§cNie znaleziono wiadomosci! §7(§f" + id + "§7)";
        return ChatColor.translateAlternateColorCodes('&', this.messages.get(id));
    }
}
