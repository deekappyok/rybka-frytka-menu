package dollar.zone4fun.listeners;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

public class ChatListener implements Listener {
    private ProxyCorePlugin instance;

    public ChatListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
    }

    @EventHandler
    public void onChat(final ChatEvent event) {
        if (!event.isCommand()) return;
        if (!(event.getSender() instanceof ProxiedPlayer)) return;

        final String message = event.getMessage().split(" ")[0];
        final ProxiedPlayer player = (ProxiedPlayer) event.getSender();
        final ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());

        if (user == null || user.isPremium() || user.isLogged()) return;
        if (message.equalsIgnoreCase("/login")
                || message.equalsIgnoreCase("/l")
                || message.equalsIgnoreCase("/register")
                || message.equalsIgnoreCase("/reg"))
            return;

        event.setCancelled(true);
    }
}
