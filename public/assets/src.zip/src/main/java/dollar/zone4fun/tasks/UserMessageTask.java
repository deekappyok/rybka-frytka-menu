package dollar.zone4fun.tasks;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

public class UserMessageTask implements Runnable {
    private final ProxyCorePlugin instance;

    public UserMessageTask(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getScheduler().schedule(this.instance, this, 2L, 2L, TimeUnit.SECONDS);
    }

    public void run() {

        for (ProxiedPlayer proxiedPlayer : ProxyServer.getInstance().getPlayers()) {
            ProxyUser proxyUser = this.instance.getProxyUsersManager().getByName(proxiedPlayer.getName());
            if (proxyUser == null) continue;
            if (proxyUser.isPremium()) continue;
            if (proxyUser.isLogged()) continue;
            if (!proxyUser.isRegistered()) {
                proxiedPlayer.sendMessage(new TextComponent(MessageHelper.colored("&7Zarejestruj swoje konto uzywajac: &a/register <haslo> <powtorz_haslo>")));
            } else {
                proxiedPlayer.sendMessage(new TextComponent(MessageHelper.colored("&7Zaloguj sie do konta uzywając komendy: &a/login <haslo>")));
            }
        }

    }
}
