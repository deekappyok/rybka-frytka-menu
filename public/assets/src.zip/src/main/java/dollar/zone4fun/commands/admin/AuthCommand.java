package dollar.zone4fun.commands.admin;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.config.ProxyServerConfig;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Arrays;

public class AuthCommand extends AbstractCommand {
    private ProxyCorePlugin instance;

    public AuthCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
        this.instance = instance;
    }

    public void execute(CommandSender sender, String[] args) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = ProxyServer.getInstance().getPlayer(sender.getName());
            ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
            if (user == null) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
            if (!user.getRankType().can(RankTypeEnum.HEADADMIN)) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
        }
        if (args.length < 1) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /auth <info/unregister/changelogintype> <nick>")));
            return;
        }
        if (args[0].equals("info") && args[1] != null) {

            ProxyUser user = this.instance.getProxyUsersManager().get(args[1]).join();
            if (user == null) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Nie znaleziono podanego gracza...")));
                return;
            }

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("&7Informacje o uzytkowniku &6").append(user.getNickName()).append("\n");
            stringBuilder.append(" ").append("\n");
            stringBuilder.append("&7Player UUID: &a").append(user.getUuid()).append("\n");
            stringBuilder.append("&7Ranga na Proxy: &a").append(user.getRankType()).append("\n");
            stringBuilder.append("&7Typ logowania: &a").append(user.isPremium() ? "PREMIUM" : "NO-REMIUM").append("\n");
            stringBuilder.append("&7Zarejestrowane konto: &a").append(user.isRegistered()).append("\n");
            stringBuilder.append("&7Konto zostalo utworzone: &a").append(user.getRegisterTime()).append("\n");
            sender.sendMessage(new TextComponent(MessageHelper.colored(stringBuilder.toString())));

            return;
        }

        if (args[0].equals("unregister") && args[1] != null) {
            ProxyUser user = this.instance.getProxyUsersManager().get(args[1]).join();
            if (user == null) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Nie znaleziono podanego gracza...")));
                return;
            }

            ProxiedPlayer player;
            if ((player = ProxyServer.getInstance().getPlayer(user.getNickName())) != null) {
                player.disconnect(new TextComponent(MessageHelper.colored("&aWejdz ponownie na serwer.")));
            }

            this.instance.getProxyUsersManager().removeProxyUser(user);
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Konto gracza &f" + user.getNickName() + " &7zostalo wlasnie usuniete!")));
            return;
        }

        if (args[0].equals("changelogintype") && args[1] != null) {
            ProxyUser user = this.instance.getProxyUsersManager().get(args[1]).join();
            if (user == null) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Nie znaleziono podanego gracza...")));
                return;
            }

            if (this.instance.getPremiumManager().getCurrentAccounts() >= this.instance.getPremiumManager().getMaxNewAccounts()) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Limit mojangowy zapchany, musisz chwile poczekac, zeby uzyc ta komende...")));
                return;
            }

            int premiumId = this.instance.getPremiumManager().getPremiumFromMojang(user.getNickName());
            if (premiumId == -1) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Wystapil blad z api mojangu, uzyj komendy za chwile...")));
                return;
            }

            boolean isPremium = this.instance.getPremiumManager().replace(premiumId);
            if (user.isPremium() == isPremium) {
                sender.sendMessage(new TextComponent(MessageHelper.colored("&4Gracz posiada te samo logowanie co zwrocilo api mojangu...")));
                return;
            }

            user.setPremium(isPremium);
            if (isPremium) {
                user.setPassword("");
                user.setRegistered(true);
            } else {
                user.setPassword("");
                user.setRegistered(false);
            }
            user.setLogged(false);
            ProxiedPlayer player;
            if ((player = ProxyServer.getInstance().getPlayer(user.getNickName())) != null) {
                player.disconnect(new TextComponent(MessageHelper.colored("&aWejdz ponownie na serwer.")));
            }

            this.instance.getProxyUsersManager().synchronize(user);
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Zmieniono typ logowania gracza &f" + user.getNickName() + " &7na &f" + (isPremium ? "PREMIUM" : "NOPREIMUM"))));
            return;
        }
        sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /auth <info/unregister/changelogintype> <nick>")));
    }
}

