package dollar.zone4fun.commands.user;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.helpers.PasswordHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Optional;

public class ChangePasswordCommand extends AbstractCommand {
    public ChangePasswordCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
    }

    public void execute(CommandSender sender, String[] arguments) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = (ProxiedPlayer) sender;
            ProxyUser authUser = this.getInstance().getProxyUsersManager().get(player.getUniqueId());
            if (authUser == null) {
                player.disconnect(new TextComponent(this.getMessage("proxy.error.to.establish.account")));
                return;
            } else if (player.getPendingConnection().isOnlineMode()) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.error.command.for.premium")));
                return;
            }
            if (!authUser.isRegistered()) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.error.register.account")));
            } else if (arguments.length < 2) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.correct.coomand.changepassowrd")));
            } else if (!PasswordHelper.encrypt(arguments[0]).equals(authUser.getPassword())) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.error.password")));
            } else {
                player.sendMessage(new TextComponent(this.getMessage("proxy.correct.password.change")));
                authUser.setPassword(PasswordHelper.encrypt(arguments[1]));
                this.getInstance().getProxyUsersManager().synchronize(authUser);
            }
        }
    }
}

