package dollar.zone4fun.managers;

import dollar.zone4fun.config.ConfigPacket;
import dollar.zone4fun.config.ProxyServerConfig;
import dollar.zone4fun.config.SettingsServerConfig;
import dollar.zone4fun.configuration.channel.ProxyMessages;
import dollar.zone4fun.packets.EmptyPacket;
import eu.dkcode.configuration.ConfigLoader;
import eu.dkcode.nats.NatsWrapper;
import eu.dkcode.nats.packet.NatsListener;
import eu.dkcode.nats.packet.NatsPublish;
import lombok.Getter;

import java.util.Objects;

public class ConfigManager {

    private final ConfigLoader configLoader;
    private final NatsWrapper nats;
    private final ChannelManager channelManager;

    public ConfigManager(ConfigLoader configLoader, NatsWrapper nats, ChannelManager channelManager) {
        this.configLoader = configLoader;
        this.nats = nats;
        this.channelManager = channelManager;
        init();
    }

    public void init(){
        this.nats.subscribe(new NatsListener<EmptyPacket>(new String[]{"configReload"}, EmptyPacket.class) {
            @Override
            public void onPacket(EmptyPacket natsPacket, String s) {
                requestConfigs();
            }
        });
        this.nats.subscribe(new NatsListener<ConfigPacket>(new String[]{"reload-server-config"}, ConfigPacket.class) {
            @Override
            public void onPacket(ConfigPacket packet, String s) {
                ConfigManager.this.serverConfig = configLoader.getGsonBuilder().create().fromJson(packet.getData(), SettingsServerConfig.class);
                System.out.println(ConfigManager.this.serverConfig.getSlots());
            }
        });

        this.requestConfigs();
    }

    private boolean isLoaded = false;

    @Getter private SettingsServerConfig serverConfig;
    @Getter private ProxyServerConfig proxyServerConfig;
    @Getter private ProxyMessages proxyMessages;
    public void requestConfigs() {
        isLoaded = false;
        new Thread(() -> {
            while (!isLoaded){
                if (this.channelManager.isActive("controller")) {
                    try {
                        ConfigPacket
                                settingsServer = this.nats.request("configRequest", new ConfigPacket("configs/proxy/settings.json", configLoader.getGsonBuilder().create().toJson(new SettingsServerConfig())),
                                ConfigPacket.class).join(),
                                proxyServerConfig = this.nats.request("configRequest", new ConfigPacket("configs/proxy/config.json", configLoader.getGsonBuilder().create().toJson(new ProxyServerConfig())),
                                        ConfigPacket.class).join(),
                                channelMessages = this.nats.request("configRequest", new ConfigPacket("configs/proxy/messages.json", configLoader.getGsonBuilder().create().toJson(new ProxyMessages())),
                                        ConfigPacket.class).join();

                        if(Objects.nonNull(settingsServer) && Objects.nonNull(channelMessages)){
                            this.serverConfig = configLoader.getGsonBuilder().create().fromJson(settingsServer.getData(), SettingsServerConfig.class);
                            this.proxyServerConfig = configLoader.getGsonBuilder().create().fromJson(proxyServerConfig.getData(), ProxyServerConfig.class);
                            this.proxyMessages = configLoader.getGsonBuilder().create().fromJson(channelMessages.getData(), ProxyMessages.class);
                        }

                        isLoaded = true;
                        System.out.println("All configs is loaded");
                    } catch (Exception ignored){}
                }
                if(!isLoaded){
                    try {
                        Thread.sleep(5000);
                        System.out.println("Waiting for controller...");
                    } catch (InterruptedException ignored) {}
                }

            }
        }).start();
    }

    public void reloadServerConfig(SettingsServerConfig serverConfig) {
        NatsPublish publish = new NatsPublish.Builder()
                .channels("save-config")
                .object(new ConfigPacket("configs/proxy/settings.json", this.configLoader.getGsonBuilder().create().toJson(serverConfig)))
                .build();
        this.nats.publish(publish);
    }

    public void reloadProxyServerConfig(ProxyServerConfig serverConfig) {
        NatsPublish publish = new NatsPublish.Builder()
                .channels("save-config")
                .object(new ConfigPacket("configs/proxy/config.json", this.configLoader.getGsonBuilder().create().toJson(serverConfig)))
                .build();
        this.nats.publish(publish);
    }
}
