package dollar.zone4fun.configuration;

public class Configuration {
    private String natsUrl;
    private String serverName;
    private String serverType;

    public Configuration() {
    }

    public Configuration(String natsUrl, String serverName, String serverType) {
        this.natsUrl = natsUrl;
        this.serverName = serverName;
        this.serverType = serverType;
    }

    public String getNatsUrl() {
        return this.natsUrl;
    }

    public String getServerName() {
        return serverName;
    }

    public String getServerType() {
        return serverType;
    }
}
