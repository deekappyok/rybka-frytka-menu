package dollar.zone4fun.listeners;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.objects.ProxyUser;
import dollar.zone4fun.packets.user.packet.UserQuitPacket;
import eu.dkcode.nats.packet.NatsPublish;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.event.EventPriority;

import java.util.concurrent.TimeUnit;

public class PlayerDisconnectListener implements Listener {
    private ProxyCorePlugin instance;

    public PlayerDisconnectListener(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getPluginManager().registerListener(instance, this);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onLoginFirst(final PlayerDisconnectEvent event) {

        final ProxiedPlayer player = event.getPlayer();
        ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
        if (user == null) return;
        user.setLogged(false);
        this.instance.getProxyUsersManager().synchronize(user);
    }

}
