package dollar.zone4fun.managers;

import com.google.gson.Gson;
import lombok.Getter;
import lombok.Setter;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

@Getter
@Setter
public class PremiumManager {
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
    private final Gson GSON = new Gson();

    private int maxNewAccounts = 5;
    private int seconds = 5;
    private int currentAccounts = 0;
    private final Map<String, Integer> cacheLogin = new ConcurrentHashMap<>();

    public PremiumManager() {
        this.executor.scheduleAtFixedRate(() -> {
            setCurrentAccounts(0);
        }, this.seconds, this.seconds, TimeUnit.SECONDS);
    }

    public boolean replace(int number) {
        return (number == 1);
    }

    public CompletableFuture<Integer> isPremium(String name) {
        return this.cacheLogin.containsKey(name)
                ? CompletableFuture.completedFuture(this.cacheLogin.get(name))
                : CompletableFuture.supplyAsync(() -> this.cacheLogin.computeIfAbsent(name, this::getPremiumFromMojang));
    }

    public Integer getPremiumFromMojang(String nick) {
        this.currentAccounts++;
        try (final InputStream localInputStream = new URL("https://api.mojang.com/users/profiles/minecraft/" + nick.toLowerCase()).openStream()) {
            return 1;
        } catch (FileNotFoundException var6) {
            return 0;
        } catch (Exception e) {
            return -1;
        }
    }

    private UUID convertUUID(final String uuid) {
        return UUID.fromString(uuid.substring(0, 8) + "-"
                + uuid.substring(8, 12) + "-"
                + uuid.substring(12, 16) + "-"
                + uuid.substring(16, 20) + "-"
                + uuid.substring(20, 32));
    }
}
