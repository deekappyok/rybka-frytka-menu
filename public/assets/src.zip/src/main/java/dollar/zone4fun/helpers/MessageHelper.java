package dollar.zone4fun.helpers;

import net.md_5.bungee.api.ChatColor;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class MessageHelper {
    private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("\\$h([a-fA-F0-9]{6})");

    public static String colored(String message) {
        return ChatColor.translateAlternateColorCodes('&', message.replace(">>", "»"));
    }

    public static List<String> colored(List<String> texts) {
        return texts.stream().map(MessageHelper::colored).collect(Collectors.toList());
    }

}