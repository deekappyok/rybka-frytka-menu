package dollar.zone4fun.tasks;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.enums.ChannelType;
import dollar.zone4fun.objects.Channel;

import java.util.concurrent.TimeUnit;

public class ProxyUpdateTask implements Runnable {
    private final ProxyCorePlugin instance;

    public ProxyUpdateTask(ProxyCorePlugin instance) {
        this.instance = instance;
        this.instance.getProxy().getScheduler().schedule(this.instance, this, 1L, 1L, TimeUnit.SECONDS);
    }

    public void run() {
        String serverName = this.instance.getProvider().provide().getServerName();

        Channel channel = this.instance.getChannelManager().get(serverName);
        if (channel == null) {
            channel = new Channel(
                    this.instance.getProvider().provide().getServerName(),
                    ChannelType.valueOf(this.instance.getProvider().provide().getServerType()),
                    System.currentTimeMillis(),
                    System.currentTimeMillis(),
                    0.0,
                    0.0,
                    0,
                    1000,
                    true
            );
        }

        if (!channel.isServerOnline()) return;
        channel.setOnlinePlayers(this.instance.getProxy().getOnlineCount());

        this.instance.getChannelManager().sendUptime(
                channel
        );

    }
}