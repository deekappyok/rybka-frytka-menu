package dollar.zone4fun.commands.user;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Optional;

public class PingCommand extends AbstractCommand {
    public PingCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
    }

    public void execute(CommandSender sender, String[] arguments) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = (ProxiedPlayer) sender;
            ProxyUser authUser = this.getInstance().getProxyUsersManager().get(player.getUniqueId());
            if (authUser == null) {
                player.disconnect(new TextComponent(this.getMessage("proxy.error.to.establish.account")));
                return;
            }
            if (!authUser.isLogged()) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.user.not.login")));
            } else if (arguments.length == 0) {
                player.sendMessage(new TextComponent(this.getMessage("proxy.user.ping").replace("{PING}", String.valueOf(player.getPing()))));
            }
        }
    }
}
