package dollar.zone4fun.tasks;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Optional;

public class UserTimeoutTask implements Runnable {

    private final ProxiedPlayer player;

    public UserTimeoutTask(final ProxiedPlayer player) {
        this.player = player;
    }

    @Override
    public void run() {
        ProxyUser user = ProxyCorePlugin.getInstance().getProxyUsersManager().get(player.getUniqueId());
        if (user == null) return;
        if (user.isLogged()) return;
        player.disconnect(new TextComponent(MessageHelper.colored("&cCzas na zalogowanie/zarejestrowanie sia minal!")));
    }

}

