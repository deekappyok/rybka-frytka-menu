package dollar.zone4fun.packets.server;

import eu.dkcode.nats.packet.NatsListener;
import net.md_5.bungee.api.ProxyServer;

public class ServerDisabledListener extends NatsListener<ServerPacket> {

    public ServerDisabledListener() {
        super(new String[]{"server-disabled"}, ServerPacket.class);
    }

    @Override
    public void onPacket(ServerPacket serverPacket, String s) {


        if (!serverPacket.getServerAddress().equals("")) ProxyServer.getInstance().getServers().remove(serverPacket.getServerName());

        System.out.println("Serwer " + serverPacket.getServerName() + " zostal usuniety z configu proxy!");
    }
}
