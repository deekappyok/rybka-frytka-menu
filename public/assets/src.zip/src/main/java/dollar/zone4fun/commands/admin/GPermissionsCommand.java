package dollar.zone4fun.commands.admin;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

import java.util.Arrays;

public class GPermissionsCommand extends AbstractCommand {
    private ProxyCorePlugin instance;

    public GPermissionsCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
        this.instance = instance;
    }

    public void execute(CommandSender sender, String[] args) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = ProxyServer.getInstance().getPlayer(sender.getName());
            ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
            if (user == null) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
            if (!user.getRankType().can(RankTypeEnum.ADMIN)) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
        }
        if (args.length < 1) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /gpex <grupa/list> <nick>")));
            return;
        }
        if (args[0].contains("list")) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Lista dostepnych rang: " + RankTypeEnum.getListRanks().toString().replace("[", "").replace("]", ""))));
            return;
        }
        RankTypeEnum rankType = RankTypeEnum.getByName(args[0]);
        if (rankType == null) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cNie odnaleziono podanej grupy")));
            return;
        }
        final ProxyUser targetUser = this.instance.getProxyUsersManager().get(args[1]).join();
        if (targetUser == null) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cNie odnaleziono podanego gracza")));
            return;
        }

        if (sender instanceof ProxiedPlayer && rankType.getPriority() > targetUser.getRankType().getPriority()) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&4Nie mozesz ustawic rangi wyzszej niz masz!")));
            return;
        }

        targetUser.setRankType(rankType);
        sender.sendMessage(new TextComponent(MessageHelper.colored("&7Zmieniles range gracza &6" + targetUser.getNickName() + " &7na &6" + rankType.name())));
        this.instance.getProxyUsersManager().synchronize(targetUser);
    }
}
