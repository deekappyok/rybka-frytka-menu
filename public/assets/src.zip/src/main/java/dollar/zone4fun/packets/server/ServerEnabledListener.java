package dollar.zone4fun.packets.server;

import dollar.zone4fun.ProxyCorePlugin;
import eu.dkcode.nats.packet.NatsListener;
import net.md_5.bungee.api.ProxyServer;

import java.net.InetSocketAddress;

public class ServerEnabledListener extends NatsListener<ServerPacket> {

    public ServerEnabledListener() {
        super(new String[]{"server-enabled"}, ServerPacket.class);
    }

    @Override
    public void onPacket(ServerPacket serverPacket, String s) {
        ProxyServer.getInstance().getServers().put(serverPacket.getServerName(),
                ProxyServer.getInstance().constructServerInfo(
                        serverPacket.getServerName(),
                        new InetSocketAddress(serverPacket.getServerAddress(), serverPacket.getPort()),
                        "null",
                        false
                ));

        System.out.println("Serwer " + serverPacket.getServerName() + " zostal zaladowany do configu proxy!");
    }
}
