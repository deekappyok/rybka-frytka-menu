package dollar.zone4fun.helpers;


import com.sun.management.OperatingSystemMXBean;

import java.lang.management.ManagementFactory;

public class ProcessHelper {

    public static double getProcessCpuLoad() {
        final OperatingSystemMXBean systemMXBean = ManagementFactory.getPlatformMXBean(OperatingSystemMXBean.class);
        return DoubleHelper.round(systemMXBean.getProcessCpuLoad() * 100.0, 2);
    }

}
