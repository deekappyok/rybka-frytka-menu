package dollar.zone4fun.commands.admin;

import dollar.zone4fun.ProxyCorePlugin;
import dollar.zone4fun.commands.AbstractCommand;
import dollar.zone4fun.config.SettingsServerConfig;
import dollar.zone4fun.enums.rank.RankTypeEnum;
import dollar.zone4fun.helpers.MessageHelper;
import dollar.zone4fun.helpers.PasswordHelper;
import dollar.zone4fun.objects.ProxyUser;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class GSlotsCommand extends AbstractCommand {
    private ProxyCorePlugin instance;

    public GSlotsCommand(ProxyCorePlugin instance, String name) {
        super(instance, name);
        this.instance = instance;
    }

    public void execute(CommandSender sender, String[] args) {
        if (sender instanceof ProxiedPlayer) {
            ProxiedPlayer player = ProxyServer.getInstance().getPlayer(sender.getName());
            ProxyUser user = this.instance.getProxyUsersManager().get(player.getUniqueId());
            if (user == null) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
            if (!user.getRankType().can(RankTypeEnum.ADMIN)) {
                sender.sendMessage(new TextComponent(this.getMessage("proxy.command.null")));
                return;
            }
        }
        if (args.length < 1) {
            sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /gslots <value>")));
            return;
        }
        int slots = Integer.parseInt(args[0]);
        if (slots >= 1) {
            SettingsServerConfig serverConfig = this.instance.getConfigManager().getServerConfig();
            serverConfig.setSlots(slots);
            this.instance.getConfigManager().reloadServerConfig(serverConfig);
            sender.sendMessage(new TextComponent(MessageHelper.colored("&7Zmieniles liczbe slotow na proxy na wartosc &f" + slots)));
            return;
        }
        sender.sendMessage(new TextComponent(MessageHelper.colored("&cPoprawne użycie: /gslots <value>")));
    }
}

